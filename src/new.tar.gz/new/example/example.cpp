/*
 * Author: Konstantin Schauwecker
 * Year:   2012
 */
 
// This is a minimalistic example on how to use the extended
// FAST feature detector and the sparse stereo matcher.

#include <opencv2/opencv.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <vector>
#include <iostream>
 #include <fstream>

#include <sparsestereo/exception.h>
#include <sparsestereo/extendedfast.h>
#include <sparsestereo/stereorectification.h>
#include <sparsestereo/sparsestereo-inl.h>
#include <sparsestereo/census-inl.h>
#include <sparsestereo/imageconversion.h>
#include <sparsestereo/censuswindow.h>
#include <fstream>

using namespace std;
using namespace cv;
using namespace sparsestereo;
using namespace boost;
using namespace boost::posix_time;
vector<KeyPoint> getKeyPoints(Mat image);
string getFileName(int lexer);
void writeCensusMatToAFile(Mat_<unsigned int> census);
void comparingOfDisparityMap(vector<SparseMatch> correspondences, int lexer,string LeftpathName, string RightpathName, string fileType,string filename, int censusWinType);
void occGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename,int censusWinType);
void nonoccGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename,int censusWinType);	
void initializeOutputDataVariables(int lexer, int censusWinType);
void printToAFile(int lexer);
Mat disparityMapOfSGBM(cv::Mat_<unsigned char> leftImg,cv::Mat_<unsigned char>  rightImg);
void SgbmGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename, Mat SGBMDisp ,int censusWinType);
void occSgbmGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename, Mat SGBMDisp,int censusWinType);
void nonoccSgbmGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename, Mat SGBMDisp,int censusWinType);

const int numOfCensusTypes = 13;
float OCCcannyResultwithinError1[numOfCensusTypes][500];
float OCCcannyResultwithinError2[numOfCensusTypes][500];
float OCCcannyResultwithinError3[numOfCensusTypes][500];
float OCCcannyResulterrorMoreThan3[numOfCensusTypes][500];
int OCCcannyResultNumberOfFeatures[numOfCensusTypes][500];
float OCCcannyResultinvalidPoint[numOfCensusTypes][500];
float OCCcannyResultwithinErrorHalf[numOfCensusTypes][500];
// float OCCcannyResulterrorMoreThanHalf[numOfCensusTypes][500];

float NOCcannyResultwithinError1[numOfCensusTypes][500];
float NOCcannyResultwithinError2[numOfCensusTypes][500];
float NOCcannyResultwithinError3[numOfCensusTypes][500];
float NOCcannyResulterrorMoreThan3[numOfCensusTypes][500];
int   NOCcannyResultNumberOfFeatures[numOfCensusTypes][500];
float NOCcannyResultinvalidPoint[numOfCensusTypes][500];
float NOCcannyResultwithinErrorHalf[numOfCensusTypes][500];
//float NOCcannyResulterrorMoreThanHalf[numOfCensusTypes][500];


float OCCSGBMResultwithinError1[numOfCensusTypes][500];
float OCCSGBMResultwithinError2[numOfCensusTypes][500];
float OCCSGBMResultwithinError3[numOfCensusTypes][500];
float OCCSGBMResulterrorMoreThan3[numOfCensusTypes][500];
int   OCCSGBMResultNumberOfFeatures[numOfCensusTypes][500];
float OCCSGBMResultinvalidPoint[numOfCensusTypes][500];
float OCCSGBMResultwithinErrorHalf[numOfCensusTypes][500];
//float OCCSGBMResulterrorMoreThanHalf[numOfCensusTypes][500];

float NOCSGBMResultwithinError1[numOfCensusTypes][500];
float NOCSGBMResultwithinError2[numOfCensusTypes][500];
float NOCSGBMResultwithinError3[numOfCensusTypes][500];
float NOCSGBMResulterrorMoreThan3[numOfCensusTypes][500];
int   NOCSGBMResultNumberOfFeatures[numOfCensusTypes][500];
float NOCSGBMResultinvalidPoint[numOfCensusTypes][500];
float NOCSGBMResultwithinErrorHalf[numOfCensusTypes][500];
//float NOCSGBMResulterrorMoreThanHalf[numOfCensusTypes][500];

std::vector<string> censusWindowName ={"1 edge","2 edge","4 edge","8 edge","12 edge","16 edge","16 Point Alter","16 Point Diamond","12 Point struct","8 Point Alter","4 Point diamond","2 Point neighb","1 Point neighb"}; 

float OCCactualExFastAverage = 0;
float NOCactualExFastAverage = 0;


ofstream myfile;
int main() {
	
	myfile.open ("outputData.txt");
	try {
		// Stereo matching parameters
		double uniqueness = 0.7;
		int maxDisp = 70;
		int leftRightStep = 2;
		
		// Feature detection parameters
		double adaptivity = 1.0;
		int minThreshold = 10;
		int edgeNo=0;
	//	int censusWindowsEdges[6]={1,2,4,8,12,16};	
		// while(!(edgeNo == 1 ||edgeNo == 2 ||edgeNo == 4 || edgeNo == 8||edgeNo == 12 ||edgeNo == 16 ))
		// {
		// 	cout<<"Enter the number of Edges "<<endl;
		// 	cout<<"i) 1"<<endl;
		// 	cout<<"i) 2"<<endl;
		// 	cout<<"i) 4"<<endl;
		// 	cout<<"i) 8"<<endl;
		// 	cout<<"i) 12"<<endl;
		// 	cout<<"i) 16"<<endl;
		// 	cin>>edgeNo; 
		// }
		// Parse arguments
		// if(argc != 3 && argc != 4) {
		// 	cout << "Usage: " << argv[0] << " LEFT-IMG RIGHT-IMG [CALIBRARION-FILE]" << endl;
		// 	return 1;
		// }
		// char* leftFile = argv[1];
		// char* rightFile = argv[2];
		 char* calibFile = NULL;
		// int count=0;
		 string LeftpathName  = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/image_0/";
		 string RightpathName  = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/image_1/";
		 string ColorLeftpathName  = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/colored_0/";
		 string ColorRightpathName  = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/colored_1/";
		int lexer;
		 string fileType = ".png";	
		 // censusWindowName.push_back(string("1 edge"));
 		//  censusWindowName.push_back("2 edge");
		 // censusWindowName.push_back("4 edge");
		 // censusWindowName.push_back("8 edge");
		 // censusWindowName.push_back("12 edge");
		 // censusWindowName.push_back("16 edge");
		 // censusWindowName.push_back("16 Point Alter");
		 // censusWindowName.push_back("16 Point Diamond");
		 // censusWindowName.push_back("12 Point struct");
		 // censusWindowName.push_back("8 Point Alter");
		 // censusWindowName.push_back("4 Point diamond");
		 // censusWindowName.push_back("2 Point neighb");
		 // censusWindowName.push_back("1 Point neighb");

		 for( lexer = 0 ; lexer <1;lexer++)
		 {

		 	//initialize the outputvariables
		 	
		 // 	//////
		 // 	//	Types of census windows - 
		 // 	1) - 1 edge 
			// 2) - 2 edge
			// 3) - 4 edge
			// 4) - 8 edge
			// 5) - 12 edge
			// 6) - 16 edge
			// 7) - 16 point alternate structure
			// 8) - 16 point diamond structure
			// 9) - 12 point structure
			// 10)- 8 point normal alternate structure
			// 11)- 4 point normal diamond structure
			// 12)- 2 point neighbourhood structure
			// 13)- 1 point neighbourhood structure
		 // 	//////

		 	cout<<"Lexer = "<<lexer<<endl;
		 	for(int censusWinType=0;censusWinType<numOfCensusTypes;censusWinType++)
		 	{
		 	initializeOutputDataVariables(lexer,censusWinType);
		 	edgeNo= censusWinType;
		 	string filename = getFileName(lexer);
			// Read input images
			cv::Mat_<unsigned char> leftImg, rightImg;
			Mat colorLeft,colorRight;
			colorLeft = imread(ColorLeftpathName+filename+fileType, CV_LOAD_IMAGE_COLOR);
			colorRight = imread(ColorRightpathName+filename+fileType, CV_LOAD_IMAGE_COLOR);
			// cout<<filename+fileType<<endl;
			// cout<<filename+fileType<<endl;
			leftImg = imread(LeftpathName+filename+fileType, CV_LOAD_IMAGE_GRAYSCALE);
			rightImg = imread(RightpathName+filename+fileType, CV_LOAD_IMAGE_GRAYSCALE);
	//	imshow("left",leftImg);
	//	imshow("right",rightImg);
		//waitKey();
	//	cout<<"Line 55"<<endl;
		if(leftImg.data == NULL || rightImg.data == NULL)
			throw sparsestereo::Exception("Unable to open input images!");

		// Load rectification data
		StereoRectification* rectification = NULL;
		if(calibFile != NULL)
			rectification = new StereoRectification(CalibrationResult(calibFile));
		
		// The stereo matcher. SSE Optimized implementation is only available for a 5x5 window
		SparseStereo<CensusWindow<5>, short> stereo(maxDisp, 1, uniqueness,
			rectification, false, false, leftRightStep);
			//	cout<<"Line 67"<<endl;

		// Feature detectors for left and right image
		// FeatureDetector* leftFeatureDetector = new ExtendedFAST(true, minThreshold, adaptivity, false, 2);
		// FeatureDetector* rightFeatureDetector = new ExtendedFAST(false, minThreshold, adaptivity, false, 2);

		// ptime lastTime = microsec_clock::local_time();
		vector<SparseMatch> correspondences;
		//		cout<<"Line 75"<<endl;

		// Objects for storing final and intermediate results
		cv::Mat_<char> charLeft(leftImg.rows, leftImg.cols),
			charRight(rightImg.rows, rightImg.cols);
		Mat_<unsigned int> censusLeft(leftImg.rows, leftImg.cols),
			censusRight(rightImg.rows, rightImg.cols);
		vector<KeyPoint> keypointsLeft, keypointsRight;
		
		// For performance evaluation we do the stereo matching 100 times
		for(int i=0; i< 1; i++) {
			// Featuredetection. This part can be parallelized with OMP
		//	#pragma omp parallel sections default(shared) num_threads(2)
			{
		//		#pragma omp section
				{
					ImageConversion::unsignedToSigned(leftImg, &charLeft);
								//	cout<<"Line 98"<<endl;

					Census::transform5x5(charLeft, &censusLeft,edgeNo);
												//		cout<<"Line 101"<<endl;

					keypointsLeft.clear();
					keypointsLeft= getKeyPoints(leftImg);
												//		cout<<"Line 106"<<endl;

				}
			//	#pragma omp section
				{
					ImageConversion::unsignedToSigned(rightImg, &charRight);
					Census::transform5x5(charRight, &censusRight,edgeNo);
					keypointsRight.clear();
						keypointsRight= getKeyPoints(rightImg);
				}
			}
					//	cout<<"Line 100"<<endl;

			// Stereo matching. Not parallelized (overhead too large)
			correspondences.clear();
																//	cout<<"Line 120"<<endl;

			stereo.match(censusLeft, censusRight, keypointsLeft, keypointsRight, &correspondences,colorLeft, colorRight);
																//	cout<<"Line 123"<<endl;



		}
	//	cout<<"Line 122"<<endl;
		//writeCensusMatToAFile(censusLeft);
		//		cout<<"Line 124"<<endl;

		Mat SGBMDisp = disparityMapOfSGBM(leftImg,rightImg); 	//to read the values use the following function(for cv_16U type values)	 (float)disp8.at<short>(i,j)/16.0f

		// Print statistics
	//	time_duration elapsed = (microsec_clock::local_time() - lastTime);
		// cout << "Time for 1x stereo matching: " << elapsed.total_microseconds()/1.0e6 << "s" << endl
		// 	<< "Features detected in left image: " << keypointsLeft.size() << endl
		// 	<< "Features detected in right image: " << keypointsRight.size() << endl
		// 	<< "Percentage of matched features: " << (1.0 * correspondences.size() / keypointsLeft.size()) << "%" << endl;

		 myfile<<"File Number = "<<filename+fileType<<"\n \n";
		 myfile<<"No of edges for census window = "<<edgeNo<<"\n";
		comparingOfDisparityMap(correspondences,lexer,LeftpathName,RightpathName,fileType,filename, censusWinType);
	//	if(censusWinType == 1)
		SgbmGTCompare(correspondences,lexer,fileType,filename,SGBMDisp,censusWinType);


		// Highlight matches as colored boxes
		Mat_<Vec3b> screen(leftImg.rows, leftImg.cols);
		screen = Mat::zeros(Size(leftImg.rows,leftImg.cols), CV_8UC3);
		cvtColor(leftImg, screen, CV_GRAY2BGR);
							//	cout<<"Line 125"<<endl;


///////#####FOR PRINTING THE VALUES ON THE IMAGE -----UNCOMMENT IT
// 		for(int i=0; i<(int)correspondences.size(); i++) {
// 			double scaledDisp = (double)correspondences[i].disparity() / maxDisp;
// 			//cout<<"Disparity = "<<(float)correspondences[i].disparity()<<endl;
// 			Vec3b color;
// 			if(scaledDisp > 0.5)
// 				color = Vec3b(0, (1 - scaledDisp)*512, 255);
// 			else color = Vec3b(0, 255, scaledDisp*512);
			
// 			rectangle(screen, correspondences[i].imgLeft->pt - Point2f(2,2),
// 				correspondences[i].imgLeft->pt + Point2f(2, 2), 
// 				(Scalar) color, CV_FILLED);
// 		}
// 					//	cout<<"Line 182"<<endl;

// //		Display image and wait
// 		namedWindow("Stereo");
// 		imshow("Stereo", screen);
// 		char  c = waitKey(3);
		// 						cout<<"Line 188"<<endl;

		// if(c ==27)
		// 	break;
	//	waitKey();
		
		// Clean up
		// delete leftFeatureDetector;
		// delete rightFeatureDetector;
		if(rectification != NULL)
			delete rectification;
			
		//return 0;
	}


	myfile<<"############################################### \n";
}

	printToAFile(lexer);

	}
	catch (const std::exception& e) {
		cerr << "Fatal exception: " << e.what();
		return 1;
	}
	myfile.close();
}


Mat disparityMapOfSGBM(cv::Mat_<unsigned char> leftImg,cv::Mat_<unsigned char>  rightImg)
{
	int SADWindowSize=3, numberOfDisparities=80;
    Ptr<StereoSGBM> sgbm = StereoSGBM::create(0,16,3);
	Mat img1 = leftImg.clone();
    Mat img2 = rightImg.clone();

    sgbm->setPreFilterCap(63);
    int sgbmWinSize = SADWindowSize > 0 ? SADWindowSize : 3;
    sgbm->setBlockSize(sgbmWinSize);

    int cn = img1.channels();

    sgbm->setP1(8*cn*sgbmWinSize*sgbmWinSize);
    sgbm->setP2(32*cn*sgbmWinSize*sgbmWinSize);
    sgbm->setMinDisparity(0);
    sgbm->setNumDisparities(numberOfDisparities);
    sgbm->setUniquenessRatio(10);
    sgbm->setSpeckleWindowSize(100);
    sgbm->setSpeckleRange(32);
    sgbm->setDisp12MaxDiff(1); 
    sgbm->setMode(StereoSGBM::MODE_SGBM);
 

    Mat disp, disp8;
    sgbm->compute(img1, img2, disp);
    disp.convertTo(disp8, CV_16U);
    

    //To display the disparity map
//  Mat show;
//  disp8.convertTo(show, CV_8U, 255/(numberOfDisparities*16.));
// 	imshow("disp8",show);
//    waitKey();
    return disp8;
}



void comparingOfDisparityMap(vector<SparseMatch> correspondences, int lexer,string LeftpathName, string RightpathName, string fileType,string filename, int censusWinType)
{
	occGTCompare(correspondences,lexer,fileType,filename,censusWinType);
	nonoccGTCompare(correspondences,lexer,fileType,filename,censusWinType);


}
void nonoccGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename, int censusWinType)
{
	string fileDirectory = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/disp_noc/";
	Mat GT = imread(fileDirectory+filename+fileType, -1);
	int totalNumberOfMatchedFeatures = correspondences.size();
	int withinError1= 0 ;
	int withinError2= 0 ; 
	int withinError3=0;
	int errorMoreThan3=0;
	int invalidPoint=0;
	int withinErrorHalf=0 ; 

	// 	ofstream  disparityFile;
	// disparityFile.open ("DisparityData.txt");
	for(int i=0;i<(int)correspondences.size();i++)
	{
	//	disparityFile<<"Point ("<<correspondences[i].imgLeft->pt.y<<" "<<correspondences[i].imgLeft->pt.x<<")"<<"="<<(float)correspondences[i].disparity()<<endl;
		if((float)(GT.at<short>(correspondences[i].imgLeft->pt)) ==0)
			invalidPoint++;
		else
		{
				float x = abs((float)correspondences[i].disparity()- (float)(GT.at<short>(correspondences[i].imgLeft->pt))/256.0);
			if(x<=0.5)
				withinErrorHalf++;
			else if(x <=1 && x>0.5 )
				withinError1++;
			else if(x<=2 && x>1)
				withinError2++ ; 
			else if(x<=3 && x>2)
				withinError3++;
			else if(x>3)
				errorMoreThan3++;
				

		
		
		}
	}
	 NOCcannyResultwithinError1[censusWinType][lexer] = withinError1;
 	 NOCcannyResultwithinError2[censusWinType][lexer] = withinError2;
	 NOCcannyResultwithinError3[censusWinType][lexer] = withinError3;
	 NOCcannyResulterrorMoreThan3[censusWinType][lexer] = errorMoreThan3;
	 NOCcannyResultNumberOfFeatures[censusWinType][lexer] = totalNumberOfMatchedFeatures;
 	 NOCcannyResultinvalidPoint[censusWinType][lexer] = invalidPoint;
 	 NOCcannyResultwithinErrorHalf[censusWinType][lexer] = withinErrorHalf;
 	// NOCcannyResulterrorMoreThanHalf[censusWinType][lexer]= greaterThanErrorHalf;

	
	// myfile<<"\nNonOcc Ground Truth Values \n ";
//	 myfile<<"\nTotal Number Of matched features = "<<totalNumberOfMatchedFeatures<<"\n";
	// myfile<<"Percentage Error within 1 disparity ="<<((float)withinError1/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	// myfile<<"Percentage Error within 2 disparity ="<<((float)withinError2/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	// myfile<<"Percentage Error within 3 disparity ="<<((float)withinError3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	// myfile<<"Percentage Error more than 3 disparity ="<<((float)errorMoreThan3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
//	 myfile<<"Percentage of Invalid  Points ="<<((float)invalidPoint/(float)totalNumberOfMatchedFeatures)*100<<endl;
	// myfile<<"---------------------------------------------------------------------------------------------------------\n \n \n";
}
void occGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename,int censusWinType)
{
	string fileDirectory = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/disp_occ/";
	Mat GT = imread(fileDirectory+filename+fileType, -1);
	int totalNumberOfMatchedFeatures = correspondences.size();
	int withinError1= 0 ;
	int withinError2= 0 ; 
	int withinError3=0;
	int errorMoreThan3=0;
	int invalidPoint=0;
		int withinErrorHalf=0 ; 
	//int greaterThanErrorHalf= 0;
	for(int i=0;i<(int)correspondences.size();i++)
	{
		if((float)(GT.at<short>(correspondences[i].imgLeft->pt)) ==0)
			invalidPoint++;
		else
		{
				float x = abs((float)correspondences[i].disparity()- (float)(GT.at<short>(correspondences[i].imgLeft->pt))/256.0);
			if(x<=0.5)
				withinErrorHalf++;
			else if(x <=1 && x>0.5 )
				withinError1++;
			else if(x<=2 && x>1)
				withinError2++ ; 
			else if(x<=3 && x>2)
				withinError3++;
			else if(x>3)
				errorMoreThan3++;

		}
	}
	 OCCcannyResultwithinError1[censusWinType][lexer] = withinError1;
	 OCCcannyResultwithinError2[censusWinType][lexer] = withinError2;
	 OCCcannyResultwithinError3[censusWinType][lexer] = withinError3;
	 OCCcannyResulterrorMoreThan3[censusWinType][lexer] = errorMoreThan3;
	 OCCcannyResultNumberOfFeatures[censusWinType][lexer] = totalNumberOfMatchedFeatures;
	 OCCcannyResultinvalidPoint[censusWinType][lexer] = invalidPoint;
	 OCCcannyResultwithinErrorHalf[censusWinType][lexer] = withinErrorHalf;
 	// OCCcannyResulterrorMoreThanHalf[censusWinType][lexer]= greaterThanErrorHalf;
	 // myfile<<"\nOcc Ground Truth Values \n ";
	//  myfile<<"\nTotal Number Of matched features = "<<totalNumberOfMatchedFeatures<<"\n";
	  // myfile<<"Percentage Error within 1 disparity ="<<((float)withinError1/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	  // myfile<<"Percentage Error within 2 disparity ="<<((float)withinError2/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	  // myfile<<"Percentage Error within 3 disparity ="<<((float)withinError3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	  // myfile<<"Percentage Error more than 3 disparity ="<<((float)errorMoreThan3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	  // myfile<<"Percentage of Invalid  Points ="<<((float)invalidPoint/(float)totalNumberOfMatchedFeatures)*100<<endl;
	 
	  myfile<<"\n\n||||||||||||||\n \n \n";
}

void occSgbmGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename, Mat SGBMDisp,int censusWinType)
{
	string fileDirectory = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/disp_occ/";
	Mat GT = imread(fileDirectory+filename+fileType, -1);
	int totalNumberOfMatchedFeatures = correspondences.size();
	int withinError1= 0 ;
	int withinError2= 0 ; 
	int withinError3=0;
	int errorMoreThan3=0;
	int invalidPoint=0;
		int withinErrorHalf=0 ; 
//	int greaterThanErrorHalf= 0;
	// 	ofstream  disparityFile;
	// disparityFile.open ("DisparityData.txt");
	for(int i=0;i<(int)correspondences.size();i++)
	{
	//	disparityFile<<"Point ("<<correspondences[i].imgLeft->pt.y<<","<<correspondences[i].imgLeft->pt.x<<")"<<"="<<(float)correspondences[i].disparity()<<endl;
		if((float)(GT.at<short>(correspondences[i].imgLeft->pt)) ==0)
			invalidPoint++;
		else
		{
			float x = abs((float)SGBMDisp.at<short>(correspondences[i].imgLeft->pt)/16.0f- (float)(GT.at<short>(correspondences[i].imgLeft->pt))/256.0);
			
			if(x<=0.5)
				withinErrorHalf++;
			else if(x <=1 && x>0.5 )
				withinError1++;
			else if(x<=2 && x>1)
				withinError2++ ; 
			else if(x<=3 && x>2)
				withinError3++;
			else if(x>3)
				errorMoreThan3++;


		}
	}
	 OCCSGBMResultwithinError1[censusWinType][lexer] = withinError1;
 	 OCCSGBMResultwithinError2[censusWinType][lexer] = withinError2;
	 OCCSGBMResultwithinError3[censusWinType][lexer] = withinError3;
	 OCCSGBMResulterrorMoreThan3[censusWinType][lexer] = errorMoreThan3;
	 OCCSGBMResultNumberOfFeatures[censusWinType][lexer] = totalNumberOfMatchedFeatures;
 	 OCCSGBMResultinvalidPoint[censusWinType][lexer] = invalidPoint;
 	 OCCSGBMResultwithinErrorHalf[censusWinType][lexer] = withinErrorHalf;
 	// OCCSGBMResulterrorMoreThanHalf[censusWinType][lexer]= greaterThanErrorHalf;


 	  // myfile<<"OCCSGBMResultwithinError1[lexer]  " <<lexer<<"="<<(OCCSGBMResultwithinError1[censusWinType][lexer]/OCCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;
 	  // myfile<<" OCCSGBMResultwithinError2[lexer]  " <<lexer<<"="<< (OCCSGBMResultwithinError2[censusWinType][lexer]/OCCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;
  	 //  myfile<<"OCCSGBMResultwithinError3[lexer]  " <<lexer<<"="<<(OCCSGBMResultwithinError3[censusWinType][lexer]/OCCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;
 	  // myfile<<"OCCSGBMResulterrorMoreThan3[lexer]   " <<lexer<<"="<< (OCCSGBMResulterrorMoreThan3[censusWinType][lexer]/OCCSGBMResultNumberOfFeatures[censusWinType][lexer])*100 <<endl;
 	  // myfile<<" OCCSGBMResultNumberOfFeatures[lexer]  " <<lexer<<"="<< OCCSGBMResultNumberOfFeatures[censusWinType][lexer]<<endl;
 	  // myfile<<" OCCSGBMResultinvalidPoint[lexer] " <<lexer<<"="<< (OCCSGBMResultinvalidPoint[censusWinType][lexer]/OCCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;
 	/*   myfile<<" OCCSGBMResultwithinErrorhalf " <<lexer<<"="<< (OCCSGBMResultwithinErrorHalf[censusWinType][lexer]/OCCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;

 	   myfile<<" OCCSGBMResultErrormorethanhalf " <<lexer<<"="<< (OCCSGBMResulterrorMoreThanHalf[censusWinType][lexer]/OCCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;*/

 	}

void SgbmGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename, Mat SGBMDisp,int censusWinType)
{
	nonoccSgbmGTCompare(correspondences,lexer,fileType,filename,SGBMDisp, censusWinType);
	occSgbmGTCompare(correspondences,lexer,fileType,filename,SGBMDisp, censusWinType);


}


void nonoccSgbmGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename, Mat SGBMDisp,int censusWinType)
{
	string fileDirectory = "/home/n1502457d/Documents/Piyush/NTU Internship/stereo matching/SparseSetero Code/Baselines/training/disp_noc/";
	Mat GT = imread(fileDirectory+filename+fileType, -1);
	int totalNumberOfMatchedFeatures = correspondences.size();
	int withinError1= 0 ;
	int withinError2= 0 ; 
	int withinError3=0;
	int errorMoreThan3=0;
	int invalidPoint=0;
		int withinErrorHalf=0 ; 
	//int greaterThanErrorHalf= 0;
	// 	ofstream  disparityFile;
	// disparityFile.open ("DisparityData.txt");
	for(int i=0;i<(int)correspondences.size();i++)
	{
	//	disparityFile<<"Point ("<<correspondences[i].imgLeft->pt.y<<","<<correspondences[i].imgLeft->pt.x<<")"<<"="<<(float)correspondences[i].disparity()<<endl;
		if((float)(GT.at<short>(correspondences[i].imgLeft->pt)) ==0)
			invalidPoint++;
		else
		{
		
			float x = abs((float)SGBMDisp.at<short>(correspondences[i].imgLeft->pt)/16.0f- (float)(GT.at<short>(correspondences[i].imgLeft->pt))/256.0);
			
			if(x<=0.5)
				withinErrorHalf++;
			else if(x <=1 && x>0.5 )
				withinError1++;
			else if(x<=2 && x>1)
				withinError2++ ; 
			else if(x<=3 && x>2)
				withinError3++;
			else if(x>3)
				errorMoreThan3++;

		}
	}
	 NOCSGBMResultwithinError1[censusWinType][lexer] = withinError1;
 	 NOCSGBMResultwithinError2[censusWinType][lexer] = withinError2;
	 NOCSGBMResultwithinError3[censusWinType][lexer] = withinError3;
	 NOCSGBMResulterrorMoreThan3[censusWinType][lexer] = errorMoreThan3;
	 NOCSGBMResultNumberOfFeatures[censusWinType][lexer] = totalNumberOfMatchedFeatures;
 	 NOCSGBMResultinvalidPoint[censusWinType][lexer] = invalidPoint;
 	 NOCSGBMResultwithinErrorHalf[censusWinType][lexer] = withinErrorHalf;
 	 //NOCSGBMResulterrorMoreThanHalf[censusWinType][lexer]= greaterThanErrorHalf;
 	 // myfile<<" NOCSGBMResultwithinErrorhalf " <<lexer<<"="<< (NOCSGBMResultwithinErrorHalf[censusWinType][lexer]/NOCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;

 	 //   myfile<<" NOCSGBMResultErrormorethanhalf " <<lexer<<"="<< (NOCSGBMResulterrorMoreThanHalf[censusWinType][lexer]/NOCSGBMResultNumberOfFeatures[censusWinType][lexer])*100<<endl;
}


// void readTheValuesOfActualExFast()
// {
// 	// ifstream myfile ("actualExFast.txt");
// 	  string line;
// 	 float array[4];
// 	 int count =0;
// 	  std::string::size_type sz; 
// 	 if (myfile.is_open())
//   	{
    
// 	    while (std::getline (myfile,line) )
// 	    {
// 	      array[count] = std::stof(line);
	      
	     
// 	      count++;
// 	    }
// 	    OCCactualExFastAverage = array[0];
// 		NOCactualExFastAverage = array[1];
// 	    cout<<"OCCactualExFastAverage = "<<OCCactualExFastAverage<<endl;
// 	    cout<<"NOCactualExFastAverage = "<<NOCactualExFastAverage<<endl;

// 	  //  myfile.close();
//   	}
//   else cout << "Unable to open exFastOutputData file"; 
// }
void printToAFile(int lexer)
{
	//to a matlab file 
	//readTheValuesOfActualExFast();
	ofstream matlabFile;
	// float OCCaverageForEdge[numOfCensusTypes] ; 
	// float NOCaverageForEdge[numOfCensusTypes] ; 
	// float OCCaverageForSGBM[numOfCensusTypes] ; 
	// float NOCaverageForSGBM[numOfCensusTypes] ; 
	matlabFile.open ("Plot.m");
	float OCCaverageForCannyEdgeWithinError1[numOfCensusTypes] ;
	float OCCaverageForCannyEdgeWithinError2[numOfCensusTypes]  ;
	float OCCaverageForCannyEdgeWithinError3[numOfCensusTypes]  ;
	float OCCaverageForCannyEdgeErrorMoreThan3[numOfCensusTypes] ;
	float OCCaverageForCannyEdgeWithinErrorHalf[numOfCensusTypes] ;
//	float OCCaverageForCannyEdgeErrorMoreThanHalf[numOfCensusTypes] ;

	float NOCaverageForCannyEdgeWithinError1[numOfCensusTypes] ;
	float NOCaverageForCannyEdgeWithinError2[numOfCensusTypes]  ;
	float NOCaverageForCannyEdgeWithinError3[numOfCensusTypes] ;
	float NOCaverageForCannyEdgeErrorMoreThan3[numOfCensusTypes] ;
	float NOCaverageForCannyEdgeWithinErrorHalf[numOfCensusTypes] ;
//	float NOCaverageForCannyEdgeErrorMoreThanHalf[numOfCensusTypes] ;


	float OCCaverageForSGBMWithinError1[numOfCensusTypes] ; 
	float OCCaverageForSGBMWithinError2[numOfCensusTypes] ; 
	float OCCaverageForSGBMWithinError3[numOfCensusTypes] ; 
	float OCCaverageForSGBMErrorMoreThan3[numOfCensusTypes] ; 
	float OCCaverageForSGBMWithinErrorHalf[numOfCensusTypes] ; 
//	float OCCaverageForSGBMErrorMoreThanHalf[numOfCensusTypes] ;


	float NOCaverageForSGBMWithinError1[numOfCensusTypes] ; 
	float NOCaverageForSGBMWithinError2[numOfCensusTypes] ; 
	float NOCaverageForSGBMWithinError3[numOfCensusTypes] ; 
	float NOCaverageForSGBMErrorMoreThan3[numOfCensusTypes] ; 
	float NOCaverageForSGBMWithinErrorHalf[numOfCensusTypes] ; 
//  float NOCaverageForSGBMErrorMoreThanHalf[numOfCensusTypes] ;


	for(int i=0;i<numOfCensusTypes;i++)
	{	
	// cout<"Census type ="<<i<<endl;
	 OCCaverageForCannyEdgeWithinError1[i] =0;
	 OCCaverageForCannyEdgeWithinError2[i]  =0;
	 OCCaverageForCannyEdgeWithinError3[i]  =0;
	 OCCaverageForCannyEdgeErrorMoreThan3[i] =0;
     OCCaverageForCannyEdgeWithinErrorHalf[i] =0;
//	 OCCaverageForCannyEdgeErrorMoreThanHalf[i] =0;

	 NOCaverageForCannyEdgeWithinError1[i] =0;
	 NOCaverageForCannyEdgeWithinError2[i]  =0;
	 NOCaverageForCannyEdgeWithinError3[i] =0;
	 NOCaverageForCannyEdgeErrorMoreThan3[i] =0;
	 NOCaverageForCannyEdgeWithinErrorHalf[i] =0;
	// NOCaverageForCannyEdgeErrorMoreThanHalf[i] =0;


	 OCCaverageForSGBMWithinError1[i] =0; 
	 OCCaverageForSGBMWithinError2[i] =0; 
	 OCCaverageForSGBMWithinError3[i] =0; 
	 OCCaverageForSGBMErrorMoreThan3[i] =0; 
	 OCCaverageForSGBMWithinErrorHalf[i]=0 ; 
	// OCCaverageForSGBMErrorMoreThanHalf[i]=0 ;


	 NOCaverageForSGBMWithinError1[i] =0; 
	 NOCaverageForSGBMWithinError2[i] =0; 
	 NOCaverageForSGBMWithinError3[i] =0; 
	 NOCaverageForSGBMErrorMoreThan3[i] =0;
	 NOCaverageForSGBMWithinErrorHalf[i]=0 ; 
	// NOCaverageForSGBMErrorMoreThanHalf[i]=0 ;
	// cout<<"Line 471"<<endl;

		for(int j=0;j<lexer;j++)
		{
			// OCCaverageForCannyEdge = OCCaverageForCannyEdge + (OCCcannyResultwithinError1[i][j]+ OCCcannyResultwithinError2[i][j] +  OCCcannyResultwithinError3[i][j])/(OCCcannyResultNumberOfFeatures[i][j] - OCCcannyResultinvalidPoint[i][j]) ; 
			// NOCaverageForCannyEdge = NOCaverageForCannyEdge + (NOCcannyResultwithinError1[i][j]+ NOCcannyResultwithinError2[i][j] +  NOCcannyResultwithinError3[i][j])/(NOCcannyResultNumberOfFeatures[i][j] - NOCcannyResultinvalidPoint[i][j]) ; 

			
			// 	OCCaverageForSGBMtemp += (OCCSGBMResultwithinError1[i][j]+ OCCSGBMResultwithinError2[i][j]+ OCCSGBMResultwithinError3[i][j])/(OCCSGBMResultNumberOfFeatures[i][j]-OCCSGBMResultinvalidPoint[i][j]);
			// 	NOCaverageForSGBMtemp += (NOCSGBMResultwithinError1[i][j] + NOCSGBMResultwithinError2[i][j]+ NOCSGBMResultwithinError3[i][j])/(NOCSGBMResultNumberOfFeatures[i][j]-NOCSGBMResultinvalidPoint[i][j]);
			

	 OCCaverageForCannyEdgeWithinError1[i] +=OCCcannyResultwithinError1[i][j]/(OCCcannyResultNumberOfFeatures[i][j] - OCCcannyResultinvalidPoint[i][j]) ;
	 OCCaverageForCannyEdgeWithinError2[i]  +=OCCcannyResultwithinError2[i][j]/(OCCcannyResultNumberOfFeatures[i][j] - OCCcannyResultinvalidPoint[i][j]) ;
	 OCCaverageForCannyEdgeWithinError3[i]  += OCCcannyResultwithinError3[i][j]/(OCCcannyResultNumberOfFeatures[i][j] - OCCcannyResultinvalidPoint[i][j]) ;
	 OCCaverageForCannyEdgeErrorMoreThan3[i] += OCCcannyResulterrorMoreThan3[i][j]/(OCCcannyResultNumberOfFeatures[i][j] - OCCcannyResultinvalidPoint[i][j]) ;
     OCCaverageForCannyEdgeWithinErrorHalf[i] +=OCCcannyResultwithinErrorHalf[i][j]/(OCCcannyResultNumberOfFeatures[i][j] - OCCcannyResultinvalidPoint[i][j]) ;
	// OCCaverageForCannyEdgeErrorMoreThanHalf[i] +=OCCcannyResulterrorMoreThanHalf[i][j]/(OCCcannyResultNumberOfFeatures[i][j] - OCCcannyResultinvalidPoint[i][j]) ;;

	 NOCaverageForCannyEdgeWithinError1[i] +=NOCcannyResultwithinError1[i][j]/(NOCcannyResultNumberOfFeatures[i][j] - NOCcannyResultinvalidPoint[i][j]) ; 
	 NOCaverageForCannyEdgeWithinError2[i]  +=NOCcannyResultwithinError2[i][j]/(NOCcannyResultNumberOfFeatures[i][j] - NOCcannyResultinvalidPoint[i][j]) ; 
	 NOCaverageForCannyEdgeWithinError3[i] +=NOCcannyResultwithinError3[i][j]/(NOCcannyResultNumberOfFeatures[i][j] - NOCcannyResultinvalidPoint[i][j]) ; 
	 NOCaverageForCannyEdgeErrorMoreThan3[i] +=NOCcannyResulterrorMoreThan3[i][j] /(NOCcannyResultNumberOfFeatures[i][j] - NOCcannyResultinvalidPoint[i][j]) ; 
	 NOCaverageForCannyEdgeWithinErrorHalf[i] +=NOCcannyResultwithinErrorHalf[i][j]/(NOCcannyResultNumberOfFeatures[i][j] - NOCcannyResultinvalidPoint[i][j]) ; 
	// NOCaverageForCannyEdgeErrorMoreThanHalf[i] +=NOCcannyResulterrorMoreThanHalf[i][j]/(NOCcannyResultNumberOfFeatures[i][j] - NOCcannyResultinvalidPoint[i][j]) ; ;

	 OCCaverageForSGBMWithinError1[i] +=OCCSGBMResultwithinError1[i][j] /(OCCSGBMResultNumberOfFeatures[i][j]-OCCSGBMResultinvalidPoint[i][j]); 
	 OCCaverageForSGBMWithinError2[i] +=OCCSGBMResultwithinError2[i][j]/(OCCSGBMResultNumberOfFeatures[i][j]-OCCSGBMResultinvalidPoint[i][j]); 
	 OCCaverageForSGBMWithinError3[i] +=OCCSGBMResultwithinError3[i][j]/(OCCSGBMResultNumberOfFeatures[i][j]-OCCSGBMResultinvalidPoint[i][j]); 
	 OCCaverageForSGBMErrorMoreThan3[i] += OCCSGBMResulterrorMoreThan3[i][j]/(OCCSGBMResultNumberOfFeatures[i][j]-OCCSGBMResultinvalidPoint[i][j]); 
	 OCCaverageForSGBMWithinErrorHalf[i] +=OCCSGBMResultwithinErrorHalf[i][j]/(OCCSGBMResultNumberOfFeatures[i][j]-OCCSGBMResultinvalidPoint[i][j]);  
	// OCCaverageForSGBMErrorMoreThanHalf[i]+=OCCSGBMResulterrorMoreThanHalf[i][j]/(OCCSGBMResultNumberOfFeatures[i][j]-OCCSGBMResultinvalidPoint[i][j]);  

	 NOCaverageForSGBMWithinError1[i] +=NOCSGBMResultwithinError1[i][j]/(NOCSGBMResultNumberOfFeatures[i][j]-NOCSGBMResultinvalidPoint[i][j]); 
	 NOCaverageForSGBMWithinError2[i] +=NOCSGBMResultwithinError2[i][j]/(NOCSGBMResultNumberOfFeatures[i][j]-NOCSGBMResultinvalidPoint[i][j]); 
	 NOCaverageForSGBMWithinError3[i] +=NOCSGBMResultwithinError3[i][j]/(NOCSGBMResultNumberOfFeatures[i][j]-NOCSGBMResultinvalidPoint[i][j]); 
	 NOCaverageForSGBMErrorMoreThan3[i] +=NOCSGBMResulterrorMoreThan3[i][j]/(NOCSGBMResultNumberOfFeatures[i][j]-NOCSGBMResultinvalidPoint[i][j]);
	 NOCaverageForSGBMWithinErrorHalf[i] +=	NOCSGBMResultwithinErrorHalf[i][j]/(NOCSGBMResultNumberOfFeatures[i][j]-NOCSGBMResultinvalidPoint[i][j]); 
	// NOCaverageForSGBMErrorMoreThanHalf[i]+=NOCSGBMResulterrorMoreThanHalf[i][j]/(NOCSGBMResultNumberOfFeatures[i][j]-NOCSGBMResultinvalidPoint[i][j]) ;

	// cout<<"Line 507"<<endl;




		}
	 OCCaverageForCannyEdgeWithinError1[i] =( OCCaverageForCannyEdgeWithinError1[i]/lexer)*100;
	 OCCaverageForCannyEdgeWithinError2[i]  =( OCCaverageForCannyEdgeWithinError2[i]/lexer)*100;
	 OCCaverageForCannyEdgeWithinError3[i]  =(OCCaverageForCannyEdgeWithinError3[i] /lexer)*100;
	 OCCaverageForCannyEdgeErrorMoreThan3[i] =(OCCaverageForCannyEdgeErrorMoreThan3[i] /lexer)*100;
     OCCaverageForCannyEdgeWithinErrorHalf[i] = (OCCaverageForCannyEdgeWithinErrorHalf[i]/lexer)*100;
   //  OCCaverageForCannyEdgeErrorMoreThanHalf[i] = ( OCCaverageForCannyEdgeErrorMoreThanHalf[i]/lexer)*100;

	 NOCaverageForCannyEdgeWithinError1[i] =(NOCaverageForCannyEdgeWithinError1[i]/lexer)*100;
	 NOCaverageForCannyEdgeWithinError2[i]  =(NOCaverageForCannyEdgeWithinError2[i] /lexer)*100;
	 NOCaverageForCannyEdgeWithinError3[i] =(NOCaverageForCannyEdgeWithinError3[i]/lexer)*100;
	 NOCaverageForCannyEdgeErrorMoreThan3[i] =(NOCaverageForCannyEdgeErrorMoreThan3[i]/lexer)*100;
     NOCaverageForCannyEdgeWithinErrorHalf[i] = (NOCaverageForCannyEdgeWithinErrorHalf[i]/lexer)*100;
    // NOCaverageForCannyEdgeErrorMoreThanHalf[i] = ( NOCaverageForCannyEdgeErrorMoreThanHalf[i]/lexer)*100;

	 OCCaverageForSGBMWithinError1[i] =(OCCaverageForSGBMWithinError1[i]/lexer)*100; 
	 OCCaverageForSGBMWithinError2[i] =( OCCaverageForSGBMWithinError2[i] /lexer)*100; 
	 OCCaverageForSGBMWithinError3[i] =( OCCaverageForSGBMWithinError3[i]/lexer)*100; 
	 OCCaverageForSGBMErrorMoreThan3[i] =(OCCaverageForSGBMErrorMoreThan3[i] /lexer)*100; 
	 OCCaverageForSGBMWithinErrorHalf[i] = (OCCaverageForSGBMWithinErrorHalf[i]/lexer)*100;
	// OCCaverageForSGBMErrorMoreThanHalf[i]=(OCCaverageForSGBMErrorMoreThanHalf[i]/lexer)*100;

	 NOCaverageForSGBMWithinError1[i] =(NOCaverageForSGBMWithinError1[i]/lexer)*100; 
	 NOCaverageForSGBMWithinError2[i] =(NOCaverageForSGBMWithinError2[i]/lexer)*100; 
	 NOCaverageForSGBMWithinError3[i] =(NOCaverageForSGBMWithinError3[i]/lexer)*100; 
	 NOCaverageForSGBMErrorMoreThan3[i] =(NOCaverageForSGBMErrorMoreThan3[i]/lexer)*100;
	 NOCaverageForSGBMWithinErrorHalf[i] = (NOCaverageForSGBMWithinErrorHalf[i]/lexer)*100;
	// NOCaverageForSGBMErrorMoreThanHalf[i]=(NOCaverageForSGBMErrorMoreThanHalf[i]/lexer)*100;

	// cout<<"Line 535"<<endl;


	}

	



	 	 matlabFile<<"yNoc = [";

		for(int j = 0; j<numOfCensusTypes;j++)
		{
				matlabFile<< NOCaverageForCannyEdgeWithinErrorHalf[j]<<" "<<NOCaverageForCannyEdgeWithinError1[j]<<" "<<NOCaverageForCannyEdgeWithinError2[j]<<" "<<NOCaverageForCannyEdgeWithinError3[j]<<" "<<NOCaverageForCannyEdgeErrorMoreThan3[j] ;	
			
			if(!(j == numOfCensusTypes-1))
	 			matlabFile<<"; ";

		}


	 matlabFile<<"] ;"<<endl;



	 	 	 matlabFile<<"yOcc = [";

		for(int j = 0; j<numOfCensusTypes;j++)
		{
				matlabFile<< OCCaverageForCannyEdgeWithinErrorHalf[j]<<" " << OCCaverageForCannyEdgeWithinError1[j]<<" "<<OCCaverageForCannyEdgeWithinError2[j]<<" "<<OCCaverageForCannyEdgeWithinError3[j]<<" "<<OCCaverageForCannyEdgeErrorMoreThan3[j] ;	
			
			if(!(j == numOfCensusTypes-1))
	 			matlabFile<<"; ";

		}


	 matlabFile<<"] ;"<<endl;



 	 matlabFile<<"sgbmNoc = [";

	for(int j = 0; j<numOfCensusTypes;j++)
	{
		matlabFile<< NOCaverageForSGBMWithinErrorHalf[j]<<" "<< NOCaverageForSGBMWithinError1[j]<<" "<<NOCaverageForSGBMWithinError2[j]<<" "<<NOCaverageForSGBMWithinError3[j]<<" "<<NOCaverageForSGBMErrorMoreThan3[j];
	
			if(!(j == numOfCensusTypes-1))
	 			matlabFile<<"; ";
	}
				 matlabFile<<"] ;"<<endl;



	 matlabFile<<"sgbmOcc = [";

	for(int j = 0; j<numOfCensusTypes;j++)
	{
		matlabFile<<OCCaverageForSGBMWithinErrorHalf[j]<<" "<<OCCaverageForSGBMWithinError1[j]<<" "<<OCCaverageForSGBMWithinError2[j]<<" "<<OCCaverageForSGBMWithinError3[j]<<" "<<OCCaverageForSGBMErrorMoreThan3[j];
	
			if(!(j == numOfCensusTypes-1))
	 			matlabFile<<"; ";
	}
				 matlabFile<<"] ;"<<endl;



//	 cout<<"Line 561"<<endl;
//1) - 1 edge 
			// 2) - 2 edge
			// 3) - 4 edge
			// 4) - 8 edge
			// 5) - 12 edge
			// 6) - 16 edge
			// 7) - 16 point alternate structure
			// 8) - 16 point diamond structure
			// 9) - 12 point structure
			// 10)- 8 point normal alternate structure
			// 11)- 4 point normal diamond structure
			// 12)- 2 point neighbourhood structure
			// 13)- 1 point neighbourhood structure

	matlabFile<<"\nx = [1:1:13] ; "<<endl;
	for(int j =0 ; j <1;j++)
	{
		matlabFile<<" figure() ; \n subplot(2,1,1); \n bar(x,yNoc);\n ";
		//matlabFile<<"for i = 1:numel(yNoc"<<j+1<<") \n text(yNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \n end"<<endl;
		matlabFile<<"grid on ; \ntitle('CannyEdgeNoc');"<<endl;
	//	matlabFile<<"\nax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	
		matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
		matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
		matlabFile<<"subplot(2,1,2); \n bar(x,sgbmNoc);\n " ; 
		//matlabFile<<"for i = 1:numel(sgbmNoc"<<j+1<<") \n text(sgbmNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \nend"<<endl;		
		matlabFile<<"grid on ; \ntitle('SGBMNoc');"<<endl;
				matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
		matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
		//cout<<"Count j= "<<j<<endl;
		// matlabFile<<"title('Comparison with NOC disparity Maps CensusType "<<censusWindowName.at(j)<<"');"<<endl;
		// matlabFile<<"ax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	}

	for(int j =0 ; j <1;j++)
	{
		matlabFile<<" figure() ; \n subplot(2,1,1); \n bar(x,yOcc);\n ";
		//matlabFile<<"for i = 1:numel(yNoc"<<j+1<<") \n text(yNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \n end"<<endl;
		matlabFile<<"grid on ; \ntitle('CannyEdgeOcc');"<<endl;
	//	matlabFile<<"\nax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	
		matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
		matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
		matlabFile<<"subplot(2,1,2); \n bar(x,sgbmOcc);\n " ; 
		//matlabFile<<"for i = 1:numel(sgbmNoc"<<j+1<<") \n text(sgbmNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \nend"<<endl;		
		matlabFile<<"grid on ; \ntitle('SGBMOcc');"<<endl;
				matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
		matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
		//cout<<"Count j= "<<j<<endl;
		// matlabFile<<"title('Comparison with NOC disparity Maps CensusType "<<censusWindowName.at(j)<<"');"<<endl;
		// matlabFile<<"ax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	}
	// 	for(int j =0 ; j <1;j++)
	// {
	// 	matlabFile<<" figure() ; \n subplot(2,1,1); \n bar(x,halfCannyNoc);\n ";
	// 	//matlabFile<<"for i = 1:numel(yNoc"<<j+1<<") \n text(yNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \n end"<<endl;
	// 	matlabFile<<"grid on ; \ntitle('CannyEdgehalfNoc');"<<endl;
	// //	matlabFile<<"\nax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	
	// 	matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
	// 	matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
	// 	matlabFile<<"subplot(2,1,2); \n bar(x,halfSgbmNoc);\n " ; 
	// 	//matlabFile<<"for i = 1:numel(sgbmNoc"<<j+1<<") \n text(sgbmNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \nend"<<endl;		
	// 	matlabFile<<"grid on ; \ntitle('SGBMhalfNoc');"<<endl;
	// 			matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
	// 	matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
	// 	//cout<<"Count j= "<<j<<endl;
	// 	// matlabFile<<"title('Comparison with NOC disparity Maps CensusType "<<censusWindowName.at(j)<<"');"<<endl;
	// 	// matlabFile<<"ax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	// }

	// for(int j =0 ; j <1;j++)
	// {
	// 	matlabFile<<" figure() ; \n subplot(2,1,1); \n bar(x,halfCannyOcc);\n ";
	// 	//matlabFile<<"for i = 1:numel(yNoc"<<j+1<<") \n text(yNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \n end"<<endl;
	// 	matlabFile<<"grid on ; \ntitle('CannyEdgehalfOcc');"<<endl;
	// //	matlabFile<<"\nax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	
	// 	matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
	// 	matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
	// 	matlabFile<<"subplot(2,1,2); \n bar(x,halfSgbmOcc);\n " ; 
	// 	//matlabFile<<"for i = 1:numel(sgbmNoc"<<j+1<<") \n text(sgbmNoc"<<j+1<<"(i) - 0.2, x(i) + 0.4, ['', num2str(x(i))], 'VerticalAlignment', 'top', 'FontSize', 8) \nend"<<endl;		
	// 	matlabFile<<"grid on ; \ntitle('SGBMhalfOcc');"<<endl;
	// 			matlabFile<<"\nax=gca; \n ax.XTickLabel = {'1Edge', '2Edge','4Edge','8Edge','12Edge', '16Edge','16PointAl','16PointDia','12Point', '8PointAl','4PointDia','2point','1point'} "<<endl;
	// 	matlabFile<<"ax.XTickLabelRotation=45;"<<endl;
	// 	//cout<<"Count j= "<<j<<endl;
	// 	// matlabFile<<"title('Comparison with NOC disparity Maps CensusType "<<censusWindowName.at(j)<<"');"<<endl;
	// 	// matlabFile<<"ax=gca; \n ax.XTickLabel = {'withinError1', 'withinError2','withinError3','errorMoreThan3'} "<<endl;
	// }

	// 	matlabFile<<"noc = [";
	// 	for(int i =0 ; i <numOfCensusTypes;i++)
	// 	{
	// 		matlabFile<<NOCaverageForEdge[i]<<" "; 
	// 		matlabFile<<NOCaverageForSGBM[i]<<" ";
	// 	}
		

	// 		// 1) - 1 edge 
	// 		// 2) - 2 edge
	// 		// 3) - 4 edge
	// 		// 4) - 8 edge
	// 		// 5) - 12 edge
	// 		// 6) - 16 edge
	// 		// 7) - 16 point alternate structure
	// 		// 8) - 16 point diamond structure
	// 		// 9) - 12 point structure
	// 		// 10)- 8 point normal alternate structure
	// 		// 11)- 4 point normal diamond structure
	// 		// 12)- 2 point neighbourhood structure
	// 		// 13)- 1 point neighbourhood structure
	// //	matlabFile <<(NOCaverageForSGBM/lexer)*100<<" " ; 
	// 	matlabFile<<"] ;"<<endl;
	// 	// matlabFile<<"NOC average for SGBM = "<<(NOCaverageForSGBM/lexer)*100 <<endl;
	// 	// matlabFile<<"OCC average for SGBM = "<<(OCCaverageForSGBM/lexer)*100 <<endl;
	// 	matlabFile<<" x = [1:1:26];"<<endl;
	// 	matlabFile<<"figure();\nbar(x,noc);\ntitle('Comparison with NOC disparity Maps');\n ax=gca;"<<endl;
	// 	matlabFile<<"ax.XTickLabel = {'CannyEdge- 1','SGBM-1', 'CannyEdge- 2','SGBM-2','CannyEdge- 4','SGBM-3','CannyEdge- 8','SGBM-4','CannyEdge- 12','SGBM-5','CannyEdge- 16','SGBM-6','16PointAlternate','SGBM-7','16PointDiamond','SGBM-8','12PointStruct','SGBM-9','8PointStruct','SGBM-10','4PointDiamond','SGBM-11' ,'2PointStruct' ,'SGBM-12', '1PointStruct','SGBM-13'}; \nax.XTickLabelRotation = 90;" <<endl;
	// 	matlabFile<<"occ = [ "; 
	// 	for(int i = 0 ; i<numOfCensusTypes;i++)
	// 	{
	// 		matlabFile<<OCCaverageForEdge[i]<<" "; 
	// 		matlabFile<<OCCaverageForSGBM[i]<<" ";

	// 	}
	// 	//matlabFile <<(OCCaverageForSGBM/lexer)*100<<" " ; 
	// 	matlabFile<<"] ;"<<endl;
	// 	matlabFile<<"figure();\nbar(x,occ);\ntitle('Comparison with OOC disparity Maps');\n ax=gca;"<<endl;
	// 	matlabFile<<"ax.XTickLabel = {'CannyEdge- 1','SGBM-1', 'CannyEdge- 2','SGBM-2','CannyEdge- 4','SGBM-3','CannyEdge- 8','SGBM-4','CannyEdge- 12','SGBM-5','CannyEdge- 16','SGBM-6','16PointAlternate','SGBM-7','16PointDiamond','SGBM-8','12PointStruct','SGBM-9','8PointStruct','SGBM-10','4PointDiamond','SGBM-11' ,'2PointStruct' ,'SGBM-12', '1PointStruct','SGBM-13'}; \nax.XTickLabelRotation = 90;" <<endl;
}	
void initializeOutputDataVariables(int lexer,int censusWinType)
{
 OCCcannyResultwithinError1[censusWinType][lexer] = 0;
 OCCcannyResultwithinError2[censusWinType][lexer] = 0;
 OCCcannyResultwithinError3[censusWinType][lexer] = 0;
 OCCcannyResulterrorMoreThan3[censusWinType][lexer] = 0;
 OCCcannyResultNumberOfFeatures[censusWinType][lexer] = 0;
 OCCcannyResultinvalidPoint[censusWinType][lexer] = 0;

 NOCcannyResultwithinError1[censusWinType][lexer] = 0;
 NOCcannyResultwithinError2[censusWinType][lexer] = 0;
 NOCcannyResultwithinError3[censusWinType][lexer] = 0;
 NOCcannyResulterrorMoreThan3[censusWinType][lexer] = 0;
 NOCcannyResultNumberOfFeatures[censusWinType][lexer] = 0;
 NOCcannyResultinvalidPoint[censusWinType][lexer] = 0;


}

string getFileName(int lexer)
{
		string filename =""; 

		int count = lexer;
		 int decimalPlaces = 0 ;
		 int decimalOuput = -1;
		 while(decimalOuput!=0)
		 {
		 	decimalOuput = count/10;
		 	count = count/10 ;
		 	decimalPlaces++ ; 
		 }
		 for(int i = 0 ;i<6-decimalPlaces;i++)		//number of 0's in the file names are 6
		 {
		 	filename = filename +"0";
		 } 
		 stringstream ss;
		 ss << lexer;
		 string fileNumber = ss.str();

		 filename = filename + fileNumber +"_10";
		 return filename;
}
void writeCensusMatToAFile(Mat_<unsigned int> census)
{
	// for(int i=0; i<census.rows;i++)
	// 	cout<<"Point ("<<i<<","<<i<<") ="<< census.at<unsigned int>(i,i)<<endl;
	Mat show = Mat::zeros( census.size(), CV_8UC1 );
	for(int i=0; i<census.rows;i++)
	{
		for(int j=0; j<census.cols;j++)
		{
			show.at<uchar>(i,j) = census.at<unsigned int>(i,j) ; 
		}
	}
    
	// imshow("Census",show);
	//  waitKey(3);
	

}
vector<KeyPoint> getKeyPoints(Mat image)
{
		//cout<<"Line 151"<<endl;

		Mat inputImage = image.clone(); //has to be 8 bit single channel
			//	cout<<"Line 154"<<endl;

		Mat edges;
		Canny( inputImage,edges, 20, 20*10,3 );
		//cout<<"Line 158"<<endl;

	//	imshow("edges",edges);
		RNG rng(12345);
		vector<KeyPoint> keypoints ;

		 vector<vector<Point> > contours;
		  vector<Vec4i> hierarchy;
		  findContours( edges, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE, Point(0, 0) );
		  		//		cout<<"Line 167"<<endl;

		  for(int i=0; i< contours.size();i++)
		  {
			  for(int j=0;j<contours[i].size();j++)
			  {
		    		keypoints.push_back(cv::KeyPoint(contours[i].at(j), 1.f));

			  }
		  }
			 return keypoints;


}


// vector<KeyPoint> getKeyPoints(Mat image)
// {

// 		Mat inputImage, input = image.clone(); //has to be 8 bit single channel
// 		input.convertTo(inputImage,IPL_DEPTH_8U,1);
// 		Mat outputImage(inputImage.rows,inputImage.cols,inputImage.depth(),Scalar(0));
// 		//cout << "image rows = " << inputImage.rows << "image cols = "<< inputImage.cols << endl ;

// 		namedWindow("outputImage",CV_WINDOW_AUTOSIZE);
// 		int thresh1 = 20 ;
// 		int thresh2 = 200 ;
// 		int apertureSize = 3;


// 			Canny(inputImage,outputImage,(double)thresh1,(double)thresh2,apertureSize,false); //true for accurate formula to be used and false for the equivalent easy formula

// 			//imshow("outputImage",outputImage);
// 			vector<vector<Point> > contours;
// 			vector<Vec4i> hierarchy;

// 			findContours( outputImage, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

// 			//cout<<"yeah1"<<endl;
// 			vector<KeyPoint> keypoints ;
// 			for(int i = 0; i < contours.size(); i++)
// 			  {
// 			    for(int j = 0; j < contours[i].size(); j++)
// 			    	{
// 			    	 //   cout<<"Points" <<i<<"="<<contours.at(i).at(j)<<endl;
// 			    		keypoints.push_back(cv::KeyPoint(contours.at(i).at(j), 1.f));
// 			    	}

// 			  }

// 			 return keypoints;


// }


	// int maxCorners = 90;
	// int qualityLevel = 5 ;	// indicates the minimal acceptable lower eigenvalue for a point to be included as a corner.
	// Mat src_gray= leftImg.clone();
	// //cvtColor( src, src_gray, CV_BGR2GRAY );
	// vector<Point2f> corners;
	// RNG rng(12345);

	//   double minDistance = 10;
	//   int blockSize = 3;
	//   bool useHarrisDetector = false;
	//   double k = 0.04;
	//   Mat copy;
	//    copy = src_gray.clone();
	//    goodFeaturesToTrack( src_gray,
	//                  corners,
	//                  maxCorners,
	//                 (double)qualityLevel/100.0,
	//                  minDistance,
	//                  Mat(),
	//                  blockSize,
	//                  useHarrisDetector,
	//                  k );
	//    std::vector<cv::KeyPoint> keypoints;
	//    cout<<"** Number of corners detected: "<<corners.size()<<endl;
	//    int r = 4;
	//    for( int i = 0; i < corners.size(); i++ )
	//       {	keypoints.push_back(cv::KeyPoint(corners.at(i), 1.f));
	// 	   //circle( copy, corners[i], r, Scalar(rng.uniform(0,255), rng.uniform(0,255),
	//           //     rng.uniform(0,255)), -1, 8, 0 ); 
	// 		}	
	// 		return keypoints;
